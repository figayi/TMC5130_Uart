#include "spi_5130.h"
#define slaveSelectPin_1_spi 10
#define slaveSelectPin_2_spi 21

#define TMC5130_CS0_Low digitalWrite(slaveSelectPin_1_spi, LOW)
#define TMC5130_CS0_High digitalWrite(slaveSelectPin_1_spi, HIGH)
//#define TMC5130_CS1_Low digitalWrite(21, LOW)
//#define TMC5130_CS1_High digitalWrite(21, HIGH)
#define TMC5130_CS1_Low digitalWrite(slaveSelectPin_2_spi, LOW)
#define TMC5130_CS1_High digitalWrite(slaveSelectPin_2_spi, HIGH)


TMC_Uart TMC5130_Uart;

uint8_t TMC_Uart::spi_sendbyte(uint8_t data,SPITransferMode mode)
{
//	return(SPI.transfer(slaveSelectPin_1_spi,data,mode));
	return(SPI.transfer(data,mode));
	//	SPI_CONTINUE,
	//SPI_LAST
}

void	TMC_Uart::delay_n1(unsigned int n)
{
 
	unsigned int i,j;
	for(i=n;i>0;i--)
		{
			for(j=200;j>0;j--);		
		}	
		
}

void TMC_Uart::ReadWrite_5130(uint8_t RW,uint8_t addr, uint8_t *sendbuf,uint8_t *readbuf)
{

//		unsigned char i;
	
		if(TMC5130_Uart.Motor_Num_Sel>=2)
			return;

		if(TMC5130_Uart.Motor_Num_Sel==Motor0)
			TMC5130_CS0_Low;
		else if(TMC5130_Uart.Motor_Num_Sel==Motor1)
			TMC5130_CS1_Low;
		
	//	TMC5130_CS0_Low;
	//	TMC5130_CS1_Low;

		delay_n1(40);
//		if(RW==00)
//				addr_rw=addr&0x7F;
//		else
//			addr_rw=addr|0x80;

/*****
	*readbuf=spi_sendbyte(addr|RW,SPI_CONTINUE); 		//addr|rw(0x80?)
		
   	*(readbuf+1)=spi_sendbyte(*sendbuf,SPI_CONTINUE);		
		*(readbuf+2)=spi_sendbyte(*(sendbuf+1),SPI_CONTINUE);
   	*(readbuf+3)=spi_sendbyte(*(sendbuf+2),SPI_CONTINUE);		
		*(readbuf+4)=spi_sendbyte(*(sendbuf+3),SPI_LAST);
*******/
			*readbuf=spi_sendbyte(addr|RW,SPI_LAST);		//addr|rw(0x80?)
			
		*(readbuf+1)=spi_sendbyte(*sendbuf,SPI_LAST);		
			*(readbuf+2)=spi_sendbyte(*(sendbuf+1),SPI_LAST);
		*(readbuf+3)=spi_sendbyte(*(sendbuf+2),SPI_LAST);		
			*(readbuf+4)=spi_sendbyte(*(sendbuf+3),SPI_LAST);

		delay_n1(20);	
		
		if(TMC5130_Uart.Motor_Num_Sel==Motor0)
			TMC5130_CS0_High;
		else if(TMC5130_Uart.Motor_Num_Sel==Motor1)
			TMC5130_CS1_High;
			
	//	TMC5130_CS0_High;
	//	TMC5130_CS1_High;
		delay_n1(20);
		
}



