#ifndef __SPI_5130_H
#define	__SPI_5130_H

#include <Wire.h>
#include <Arduino.h>
#include <stdint.h>
#include <SPI.h>

class TMC_Uart{
public:

	void ReadWrite_5130(uint8_t RW, uint8_t addr,uint8_t *sendbuf,uint8_t *readbuf); 
	uint8_t spi_sendbyte(uint8_t data,SPITransferMode mode);
	uint8_t Motor_Num_Sel;
#define Motor0 0
#define Motor1 1

	
private:


	void delay_n1(unsigned int n);


#define abcdefg 1
};

extern TMC_Uart TMC5130_Uart;

#endif
